package com.example.variousimplicitintent;

import androidx.appcompat.app.AppCompatActivity;

import android.app.SearchManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button1,button2,button3,button4;

        //암시적 인텐트 예제
        //버튼 4개 가져오기

        //첫 번째 버튼: 지도 어플로 이동
        button1 = findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent map = new Intent();
                //setAction: 액션을 지정
                map.setAction(Intent.ACTION_VIEW);
                //setData(), URI.parse(): 지도 위치 설정
                //geo: 위도 , 경도?q = 원하는 지역
                map.setData(Uri.parse("geo:0,0?q=seoul"));
                //startActivity(인텐트명)
                startActivity(map);
            }
        });

        //두 번째 버튼: 검색창으로 이동
        button2 = findViewById(R.id.button2);
        //상수: action_web_search
        //데이터를 전달: putExtra();
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent search = new Intent(Intent.ACTION_WEB_SEARCH);
                //search.putExtra(질의문장 매갭ㄴ수,질의에 대한 값);
                search.putExtra(SearchManager.QUERY, "서울디지텍고등학교");
                startActivity(search);
            }
        });

        //세 번째 버튼: 연락처로 이동
        button3 = findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent contact = new Intent();
                contact.setAction(Intent.ACTION_VIEW);
                //setDATA() 주소록의 자료를 화면에 표시
                contact.setData(ContactsContract.Contacts.CONTENT_URI);
                startActivity(contact);
            }
        });

        //네 번째 버튼: 이메일로 이동
        button4 = findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //먼저 주어진 이메일 주소를 uri 객체의 parse를 사용하여 파싱을 처리
                //파싱이란 원하는 자료를 구분 분석하여 원하는 자료를 가져오는 것을 말함
                //여기서 원하는 이메일 서버, 메일 설정 기능을  분석하여 가져오게 됨
                Uri email = Uri.parse("mailto:test@hotmail.com");
                //위에 생성한 이메일에 대한 uri 객체를 지정해주어 암시적 인텐트 호출에 대한 준비를 함
                Intent emailInt = new Intent(Intent.ACTION_SENDTO, email);
                startActivity(emailInt);
            }
        });

    }

    }
